package kr.co.noori.back.equipment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RentVO {
    private String id;
    private String rname;
    private int cnt;
}