package kr.co.noori.back.equipment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberVO {
    private Long num;
    private String name;
    private String id;
}