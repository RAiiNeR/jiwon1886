package kr.co.noori.back.equipment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EquipmentVO {
    private Long num;
    private String rname;
    private String state;
    private int cnt;
}