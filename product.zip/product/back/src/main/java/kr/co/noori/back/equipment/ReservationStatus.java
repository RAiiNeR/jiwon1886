package kr.co.noori.back.equipment;

public enum ReservationStatus {
    WAITING,   // 대기 중
    NOTIFIED,  // 알림 발송됨
    COMPLETED //완료
}
